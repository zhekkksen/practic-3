import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  useColorScheme
} from 'react-native';

export default function App() {

  const systemTheme = useColorScheme();
  const [isDark, setIsDark] = useState(systemTheme === 'dark');

  const theme = isDark ? darkTheme : lightTheme;

  const data = Array.from({ length: 30 }, (_, i) => ({
    id: i.toString(),
    day: `Day ${i + 1}`,
    title: `Wellness Tip #${i + 1}`,
    description:
      "Take time today to focus on your physical and mental well-being. Small consistent steps lead to big results over time.",
    image: `https://picsum.photos/400/300?random=${i + 1}`
  }));

  const renderItem = ({ item }) => (
    <View style={[styles.card, { backgroundColor: theme.card }]}>
      <Text style={[styles.day, { color: theme.accent }]}>{item.day}</Text>

      <Text style={[styles.title, { color: theme.text }]}>
        {item.title}
      </Text>

      <Image
        source={{ uri: item.image }}
        style={styles.image}
      />

      <Text style={[styles.description, { color: theme.textSecondary }]}>
        {item.description}
      </Text>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background }]}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      <View style={styles.header}>
        <Text style={[styles.headerText, { color: theme.text }]}>
          30 Days of Wellness
        </Text>

        <TouchableOpacity
          style={[styles.themeButton, { backgroundColor: theme.primary }]}
          onPress={() => setIsDark(!isDark)}
        >
          <Text style={{ color: '#fff' }}>
            {isDark ? "Light" : "Dark"}
          </Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={data}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        showsVerticalScrollIndicator={false}
      />
    </SafeAreaView>
  );
}

const lightTheme = {
  background: "#F5F7FA",
  card: "#FFFFFF",
  primary: "#4CAF50",
  accent: "#2E7D32",
  text: "#222222",
  textSecondary: "#555555"
};

const darkTheme = {
  background: "#121212",
  card: "#1E1E1E",
  primary: "#81C784",
  accent: "#A5D6A7",
  text: "#FFFFFF",
  textSecondary: "#BBBBBB"
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 16
  },
  headerText: {
    fontSize: 22,
    fontWeight: 'bold'
  },
  themeButton: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8
  },
  card: {
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    elevation: 3
  },
  day: {
    fontSize: 14,
    marginBottom: 4
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8
  },
  image: {
    width: "100%",
    height: 180,
    borderRadius: 10,
    marginBottom: 10
  },
  description: {
    fontSize: 14,
    lineHeight: 20
  }
});
